<?php
    if (!isset($page)) exit;
?>
<div class="container">
    <div class="card mt-5 mb-5 shadow">
        <div class="card-header">
            <h2>Atalhos</h2>
        </div>
        <div class="card-body">
            <div class="row">
                <div class="col-12 col-md-4 text-center shadow">
                    <?php
                        $sqlCategoria = "SELECT COUNT(id) as conta
                                        FROM categoria
                                        LIMIT 1";
                        $consultaCategoria = $pdo->prepare($sqlCategoria);
                        $consultaCategoria->execute();

                        $categoria = $consultaCategoria->fetch(PDO::FETCH_OBJ)->conta;
                    ?>
                    <div class="alert alert-info text-center p-4">
                        <h2>Categorias</h2>
                        <p>Temos <?= $categoria ?> cadastradas no Sistema!</p>
                        <p>
                            <a href="cadastrar/categoria" title="Categoria" class="btn btn-info w-100">
                                Cadastrar Categorias
                            </a>
                        </p>
                    </div>
                </div>
                <div class="col-12 col-md-4 text-center shadow">
                    <?php
                        $sqlFilmes = "SELECT COUNT(id) as conta
                                        FROM filme
                                        LIMIT 1";
                        $consultaFilmes = $pdo->prepare($sqlFilmes);
                        $consultaFilmes->execute();

                        $Filmes = $consultaFilmes->fetch(PDO::FETCH_OBJ)->conta;
                    ?>
                    <div class="alert alert-warning text-center p-4">
                        <h2>Filmes</h2>
                        <p>Temos <?= $Filmes ?> cadastradas no Sistema!</p>
                        <p>
                            <a href="cadastrar/filme" title="Categoria" class="btn btn-warning w-100">
                                Cadastrar Filmes
                            </a>
                        </p>
                    </div>
                </div>

                <div class="col-12 col-md-4 text-center shadow">
                    <?php
                        $sqlUsuarios = "SELECT COUNT(id) as conta
                                        FROM usuario
                                        LIMIT 1";
                        $consultaUsuarios = $pdo->prepare($sqlUsuarios);
                        $consultaUsuarios->execute();

                        $Usuarios = $consultaUsuarios->fetch(PDO::FETCH_OBJ)->conta;
                    ?>
                    <div class="alert alert-danger text-center p-4">
                        <h2>Usuarios</h2>
                        <p>Temos <?= $Usuarios ?> cadastradas no Sistema!</p>
                        <p>
                            <a href="cadastrar/usuario" title="Categoria" class="btn btn-danger w-100">
                                Cadastrar Usuarios
                            </a>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>