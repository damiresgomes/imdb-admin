<?php

    if (!isset($page)) exit;

    $pdo->beginTransaction();//nao executa enquanto nn tiver pdo commit

    if (empty($id)) { //se estiver vazio
        echo "<script>mensagem('Registro inválido','erro');</script>";
        exit;
    }

    $sqlCategoria = "SELECT id FROM filme WHERE categoria_id = :id LIMIT 1";
    $consultaCategoria = $pdo->prepare($sqlCategoria);
    $consultaCategoria->bindParam(":id", $id);
    $consultaCategoria->execute();

    $dadosCategoria = $consultaCategoria->fetch(PDO::FETCH_OBJ);

    if (!empty($dadosCategoria->id)) { ///se nao estiver em branco, este trazendo um filme
        echo "<script>mensagem('Não foi possível excluir, pois existe um filme cadastrado com esta categoria','erro');</script>";
        exit;

    }

    $sqlDelete = "DELETE FROM categoria WHERE id = :id LIMIT 1";
    $consultaDelete = $pdo->prepare($sqlDelete);
    $consultaDelete->bindParam(":id", $id);
    
    if ($consultaDelete->execute()) {
        $pdo->commit();
        echo "<script>mensagem('Registro excluído','ok','listar/categoria');</script>";
        exit;

    } else {
        echo "<script>mensagem('Erro ao excluir categoria','erro');</script>";
        exit;

    }