<?php 
    if (!isset($page)) exit; 

    $id = $param[2] ?? NULL;

    if (!empty($id)) {
        $sqlCadastro = "SELECT * FROM banner WHERE id = :id LIMIT 1";
        $consultaCadastro = $pdo->prepare($sqlCadastro);
        $consultaCadastro->bindParam(":id", $id);
        $consultaCadastro->execute();
        $dadosCadastro = $consultaCadastro->fetch(PDO::FETCH_OBJ);
    }

    $id = $dadosCadastro->id ?? NULL;
    $descricao = $dadosCadastro->descricao ?? NULL;
    $banner = $dadosCadastro->banner ?? NULL;
    $ativo = $dadosCadastro->ativo ?? 'S';
?>

<div class="container pt-5 pb-5">
    <div class="card shadow">
        <div class="card-header">
            <div class="float-start">
                <h2>Cadastro de Banner</h2>
            </div>
            <div class="float-end">
                <a href="cadastrar/banner" class="btn btn-success">Cadastrar Novo</a>
                <a href="listar/banner" class="btn btn-success">Listar Registro</a>
            </div>
        </div>
        <div class="card-body">
            <form name="formCadastro" method="post" action="salvar/banner" data-parsley-validate="" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-12 col-md-2 mb-3">
                        <label for="id">ID</label>
                        <input type="text" name="id" id="id" value="<?= $id ?>" class="form-control" readonly>
                    </div>

                    <div class="col-12 col-md-7 mb-3">
                        <label for="banner">Imagem do Banner</label>
                        <input type="file" name="banner" id="banner" class="form-control" accept=".jpg,.png,.jpeg">
                    </div>

                    <div class="col-12 col-md-3 mb-3">
                        <label for="ativo">Ativo</label>
                        <select name="ativo" id="ativo" class="form-control" required data-parsley-required-message="Selecione o status">
                            <option value="S">Sim</option>
                            <option value="N">Não</option>
                        </select>
                        <script>
                            $("#ativo").val("<?= $ativo ?>");
                        </script>
                    </div>

                    <div class="col-12 col-md-12 mb-3">
                        <label for="descricao">Descrição / Conteúdo</label>
                        <textarea name="descricao" id="descricao" class="form-control text" required data-parsley-required-message="Preencha este campo"><?= $descricao ?></textarea>
                    </div>
                </div>
                <br>
                <div class="float-end">
                    <button type="submit" class="btn btn-success">
                        Salvar
                    </button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    $(document).ready(function() {
        $('.text').summernote();
    });
</script>