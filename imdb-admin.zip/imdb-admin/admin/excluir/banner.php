<?php
    if (!isset($page))
    exit;

    if (empty($id)) {
        echo "<script>mensagem('Banner não encontrado!','error','listar/banner');</script>";
        exit;
    } else {
        $sql = "select banner from banner where id = :id limit 1";
        $consulta = $pdo->prepare($sql);
        $consulta->bindParam(":id", $id);
        $consulta->execute();

        $dadosBanner = $consulta->fetch(PDO::FETCH_OBJ);

        if (!empty($dadosBanner->banner)) {
            $arquivo = "../arquivos/{$dadosBanner->banner}";

            // Excluir a imagem do servidor se o arquivo existir
            if (file_exists($arquivo)) {
                unlink($arquivo);
            }
        }

        $sql = "delete from banner where id = :id limit 1";
        $consulta = $pdo->prepare($sql);
        $consulta->bindParam(":id", $id);

        if ($consulta->execute()) {
            echo "<script>mensagem('Banner excluído com sucesso!','success','listar/banner');</script>";
            exit;
        } else {
            echo "<script>mensagem('Erro ao excluir o banner!','error','listar/banner');</script>";
            exit;
        }
    }