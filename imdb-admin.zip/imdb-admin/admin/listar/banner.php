<?php
    if (!isset($page))
    exit;
?>

<div class="container pt-5 pb-5">
    <div class="card shadow">
        <div class="card-header">
            <div class="float-start">
                <h2>Listagem de Banners</h2>
            </div>

            <div class="float-end">
                <a href="cadastrar/banner" class="btn btn-success">
                    Novo Registro
                </a>

                <a href="listar/banner" class="btn btn-success">
                    Listar registros
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <th>Banner</th>
                        <th>ID</th>
                        <th>Descrição</th>
                        <th>Ativo</th>
                        <th>Opções</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $sqlListar = "SELECT id, descricao, banner, ativo FROM banner ORDER BY id DESC";

                    $consultaListar = $pdo->prepare($sqlListar);
                    $consultaListar->execute();

                    $dadosListar = $consultaListar->fetchAll(PDO::FETCH_OBJ);

                    foreach ($dadosListar as $dados) {
                        // Trata o texto HTML vindo do banco/Summernote para exibição limpa
                        $descricaoLimpa = html_entity_decode($dados->descricao);
                        $status = ($dados->ativo == 'S') ? '<span class="badge bg-success">Sim</span>' : '<span class="badge bg-danger">Não</span>';
                        ?>
                        <tr>
                            <td class="text-center" style="width: 100px;">
                                <?php if (!empty($dados->banner)): ?>
                                    <img src="../arquivos/<?= $dados->banner ?>"
                                         alt="Banner <?= $dados->id ?>" width="80px" class="img-thumbnail">
                                <?php else: ?>
                                    <span class="badge bg-secondary">Sem imagem</span>
                                <?php endif; ?>
                            </td>
                            <td><?= $dados->id ?></td>

                            <td><?= strip_tags($descricaoLimpa) ?></td>

                            <td><?= $status ?></td>

                            <td style="width: 180px;">
                                <a href="cadastrar/banner/<?= $dados->id ?>" class="btn btn-success btn-sm">
                                    Editar
                                </a>

                                <a href="javascript:excluir(<?= $dados->id ?>)" class="btn btn-danger btn-sm">
                                    Excluir
                                </a>
                            </td>
                        </tr>
                        <?php
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<script>
    function excluir(id) {
        if (confirm("Deseja realmente excluir este banner?")) {
            location.href = "excluir/banner/" + id;
        }
    }

    $(document).ready(function() {
        $('.table').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por página",
                "zeroRecords": "Nada encontrado",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "Nenhum registro disponível",
                "infoFiltered": "(filtrado de _MAX_ registros no total)",
                "search": "Buscar:",
                "paginate": {
                    "first": "Primeiro",
                    "last": "Último",
                    "next": "Próximo",
                    "previous": "Anterior"
                }
            }
        });
    });
</script>