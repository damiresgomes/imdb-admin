<?php
    if (!isset($page))
    exit;

    if ($_POST) {

        $id = htmlspecialchars(trim($_POST["id"] ?? NULL));
        $descricao = trim($_POST["descricao"] ?? NULL);
        $ativo = htmlspecialchars(trim($_POST["ativo"] ?? 'S'));

        $arquivo = NULL;

        if (!empty($_FILES["banner"]["name"])) {
            $prefixo = $_SESSION["imdb"]["id"] ?? time();
            $nomeArquivo = $prefixo . "_" . time() . ".jpg";
            $destino = "../arquivos/{$nomeArquivo}";

            if (move_uploaded_file($_FILES["banner"]["tmp_name"], $destino)) {
                $arquivo = $nomeArquivo;
                
                if (function_exists('redimensionarImagem')) {
                    redimensionarImagem($destino, 1200, 400, 100);
                }
            } else {
                echo "<script>mensagem('Falha ao enviar o arquivo de imagem','error');</script>";
                exit;
            }
        }

        if (empty($id)) {
            if (empty($arquivo)) {
                echo "<script>mensagem('Selecione uma imagem para o banner','error');</script>";
                exit;
            }

            $sqlCadastro = "INSERT INTO banner (descricao, banner, ativo) 
                            VALUES (:descricao, :banner, :ativo)";
                            
            $consultaCadastro = $pdo->prepare($sqlCadastro);
            $consultaCadastro->bindParam(":descricao", $descricao);
            $consultaCadastro->bindParam(":banner", $arquivo);
            $consultaCadastro->bindParam(":ativo", $ativo);

        } else if (empty($arquivo)) {
            $sqlCadastro = "UPDATE banner 
                            SET descricao = :descricao, ativo = :ativo 
                            WHERE id = :id 
                            LIMIT 1";

            $consultaCadastro = $pdo->prepare($sqlCadastro);
            $consultaCadastro->bindParam(":descricao", $descricao);
            $consultaCadastro->bindParam(":ativo", $ativo);
            $consultaCadastro->bindParam(":id", $id);

        } else {
            $sqlCadastro = "UPDATE banner 
                            SET descricao = :descricao, banner = :banner, ativo = :ativo 
                            WHERE id = :id 
                            LIMIT 1";

            $consultaCadastro = $pdo->prepare($sqlCadastro);
            $consultaCadastro->bindParam(":descricao", $descricao);
            $consultaCadastro->bindParam(":banner", $arquivo);
            $consultaCadastro->bindParam(":ativo", $ativo);
            $consultaCadastro->bindParam(":id", $id);
        }

        if ($consultaCadastro->execute()) {
            echo "<script>mensagem('Banner salvo com sucesso!','success','listar/banner');</script>";
            exit;
        } else {
            echo "<script>mensagem('Falha ao salvar o banner no banco de dados.','error');</script>";
            exit;
        }

    } else {
        echo "<script>mensagem('Requisição inválida','error');</script>";
        exit;
    }