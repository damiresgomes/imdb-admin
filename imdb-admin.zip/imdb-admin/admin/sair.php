<?php
    session_start();
    unset($_SESSION["imdb"]);
    echo "<script>location.href='index.php'</script>";