<?php
    if (!isset($page)) exit;
?>

<div class="container pt-5 pb-5">
    <div class="card shadow">
        <div class="card-header">
            <div class="float-start">
                <h2>Listagem de Filmes</h2>
            </div>

            <div class="float-end">
                <a href="cadastrar/filme" class="btn btn-success">
                    Novo Registro
                </a>

                <a href="listar/filme" class="btn btn-success">
                    Listar registros
                </a>
            </div>
        </div>
        <div class="card-body">
            <table class="table table-bordered table-striped">
                <thead>
                    <tr>
                        <td>Capa</td>
                        <td>ID</td>
                        <td>Titulo</td>
                        <td>Categoria</td>
                        <td>Opcoes</td>
                    </tr>
                    <tbody>
                        <?php
                        $sqlListar = "SELECT
                                      f.id,
                                      f.capa,
                                      f.titulo,
                                      c.categoria,
                                      f. youtube
                                      FROM filme as f
                                      INNER JOIN categoria as c
                                      ON (c.id = f.categoria_id)
                                      ORDER BY f.titulo";

                        $consultaListar = $pdo->prepare($sqlListar);
                        $consultaListar->execute();

                        $dadosListar = $consultaListar->fetchAll(PDO::FETCH_OBJ);

                        foreach ($dadosListar as $dados) {
                            ?>
                            <tr>
                                <td>
                                    <img src="../arquivos/<?= $dados->capa ?>"
                                    alt="<?= $dados->titulo ?>" width="60px">
                                </td>
                                <td><?= $dados->id ?></td>

                                <td>
                                    <a href="https://www.youtube.com/watch?v=<?= $dados->youtube ?>"
                                    target="youtube">
                                        <?= $dados->titulo ?>
                                    </a>
                                </td>

                                <td><?= $dados->categoria ?></td>

                                <td>
                                    <a href="cadastrar/filme/<?= $dados->id ?>" class="btn btn-success">
                                        Editar
                                    </a>

                                    <a href="javascript:excluir(<?= $dados->id ?>)" class="btn btn-danger">
                                        Excluir
                                    </a>
                                </td>
                            </tr>
                            <?php
                        }
                        ?>
                    </tbody>
                </thead>
            </table>
        </div>
    </div>
</div>
<script>
    $(document).ready(function() {
        $('.table').DataTable({
            "language": {
                "lengthMenu": "Mostrar _MENU_ registros por página",
                "zeroRecords": "Nada encontrado",
                "info": "Mostrando página _PAGE_ de _PAGES_",
                "infoEmpty": "Nenhum registro disponível",
                "infoFiltered": "(filtrado de _MAX_ registros no total)",
                "search": "Buscar:",
                "paginate": {
                    "first": "Primeiro",
                    "last": "Último",
                    "next": "Próximo",
                    "previous": "Anterior"
                }
            }
        });
    });
</script>