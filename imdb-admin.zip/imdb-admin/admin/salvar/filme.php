<?php
    if (!isset($page)) exit;

    if ($_POST) {

    $id = htmlspecialchars(trim($_POST["id"] ?? NULL));
    $titulo = htmlspecialchars(trim($_POST["titulo"] ?? NULL));
    $original = htmlspecialchars(trim($_POST["original"] ?? NULL));
    $ano = htmlspecialchars(trim($_POST["ano"] ?? NULL));
    $categoria_id = htmlspecialchars(trim($_POST["categoria_id"] ?? NULL));
    $youtube = htmlspecialchars(trim($_POST["youtube"] ?? NULL));
    $sinopse = htmlspecialchars(trim($_POST["sinopse"] ?? NULL));

    $arquivo = $_SESSION["imdb"]["id"] . "_" . time();

    if ((!empty($_FILES["capa"]["name"])) && (!move_uploaded_file($_FILES["capa"]["tmp_name"], "../arquivos/{$arquivo}.jpg"))) {
        echo "<script>mensagem('Falha ao enviar arquivo','error');</script>";
        exit;
    }

    if (!empty($_FILES["capa"]["name"])) {
        $origem = "../arquivos/{$arquivo}.jpg";
        redimensionarImagem($origem, 600, 800, 100);
    }

    $arquivo = "{$arquivo}.jpg";

    if (empty($id)) {
         if (empty($_FILES["capa"]["name"])) {
                echo "<script>mensagem('Selecione um arquivo','erro');</script>";
                exit;
            } else if (!move_uploaded_file($_FILES["capa"]["tmp_name"], "../arquivos/{$arquivo}")) {
                echo "<script>mensagem('Erro ao copiar arquivo','erro');</script>";
                exit;
            }


        //inserindo
        $sqlCadastro = "INSERT INTO filme,
                        VALUES (NULL, :titulo, :original, :ano, :categoria_id, :youtube, :capa, :sinopse)";
        $consultaCadastro = $pdo->prepare($sqlCadastro);
        $consultaCadastro->bindParam(":titulo", $titulo);
        $consultaCadastro->bindParam(":original", $original);
        $consultaCadastro->bindParam(":ano", $ano);
        $consultaCadastro->bindParam(":categoria_id", $categoria_id);
        $consultaCadastro->bindParam(":youtube", $youtube);
        $consultaCadastro->bindParam(":capa", $arquivo);
        $consultaCadastro->bindParam(":sinopse", $sinopse);



    } else if (empty($_FILES["capa"]["name"])) {
        //atualizando sem capa
        $sqlCadastro = "UPDATE filme
                        SET titulo = :titulo, original = :original, ano = :ano, categoria_id = :categoria_id,
                        youtube = :youtube, sinopse = :sinopse
                        WHERE id = :id
                        LIMIT 1";

        $consultaCadastro = $pdo->prepare($sqlCadastro);
        $consultaCadastro->bindParam(":titulo", $titulo);
        $consultaCadastro->bindParam(":original", $original);
        $consultaCadastro->bindParam(":ano", $ano);
        $consultaCadastro->bindParam(":categoria_id", $categoria_id);
        $consultaCadastro->bindParam(":youtube", $youtube);
        $consultaCadastro->bindParam(":sinopse", $sinopse);
        $consultaCadastro->bindParam(":id", $id);         

    } else {
        //atualizar
        $sqlCadastro = "UPDATE filme
                        SET titulo = :titulo, original = :original, ano = :ano, categoria_id = :categoria_id,
                        youtube = :youtube, sinopse = :sinopse, capa = :capa
                        WHERE id = :id
                        LIMIT 1";

        $consultaCadastro = $pdo->prepare($sqlCadastro);
        $consultaCadastro->bindParam(":titulo", $titulo);
        $consultaCadastro->bindParam(":original", $original);
        $consultaCadastro->bindParam(":ano", $ano);
        $consultaCadastro->bindParam(":categoria_id", $categoria_id);
        $consultaCadastro->bindParam(":youtube", $youtube);
        $consultaCadastro->bindParam(":sinopse", $sinopse);
        $consultaCadastro->bindParam(":id", $id); 
        $consultaCadastro->bindParam(":capa", $arquivo); 
    }

    if ($consultaCadastro->execute()) {
        echo "<script>mensagem('Registro salvo com sucesso','success','listar/filme');</script>";
        exit;
    } else {
        echo "<script>mensagem('Falha ao salvar registro','error');</script>";
        exit;
    }
    } else {
        echo "<script>mensagem('Requisicao invalida','error');</script>";
        exit;
    }